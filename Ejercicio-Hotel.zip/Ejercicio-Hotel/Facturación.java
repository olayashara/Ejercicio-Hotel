/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.mavenproject2;

/**
 *
 * @author maria
 */
public class Facturación {

    static Lectura mu= new Lectura();
    static String nombre;
    static int nroFactura;
    static int nroRoom;
    static int tipo;
    static int precio;
    static int lavanderia;
    static int tiempo;
    static int daños;
    static int costoTotal = 0;
    
    public static void datos(){
        nombre = mu.leerString("Nombre del cliente: ");
        nroFactura = mu.leeryValidarInt("Número de factura: ");
        nroRoom = mu.leeryValidarInt("Ingrese el número de la habitación");
        tipo = mu.leeryValidarInt("Igrese 1 si es individual, 2 si es doble, 3 si es familiar, 4 si es suite ");
        lavanderia = mu.leeryValidarInt("Costo total de lavandería sin comas ni puntos: ");
        tiempo = mu.leeryValidarInt("Ingrese el tiempo de estadía en días: ");
        daños = mu.leeryValidarInt("Ingrese los costos de los daños o robos ocasionados: ");
    }
     public static int precioRoom(){
        return switch (tipo) {
            case 1 -> 150;
            case 2 -> 130;
            case 3 -> 300;
            case 4 -> 415;
            default -> 0;
        };
    }
    public static void ingresoDatos(){
      Bill fact1 = new Bill(); 
      Room fact2 = new Room();
      fact1.setBillNo(nroFactura);
      fact1.setGuestName(nombre);
      fact2.setPrecio(precioRoom());
      fact2.setTiempo(tiempo);
      fact2.setNroHabitación(nroRoom);
      fact2.setLocation(tipo);
      fact2.setLavanderia(lavanderia);
      nroFactura = fact1.getBillNo();
      nombre = fact1.getGuestName();
      precio = fact2.getPrecio();
      tiempo = fact2.getTiempo();
      nroRoom = fact2.getNroHabitación();
      tipo = fact2.getLocation();
      lavanderia = fact2.getLavanderia();
      
      imprimir(fact2.toString());
      imprimir(fact1.toString() + " con un precio a pagar de " + costoTotal);

    }
    public static void costoTotal(){
        costoTotal = (precioRoom()*tiempo) + daños + lavanderia;
    }
    public static void imprimir(String cadena){
        System.out.println(cadena);
    }
    public static void main(String[] args) {
      datos();
      precioRoom();
      costoTotal();
      ingresoDatos();
    }
}
