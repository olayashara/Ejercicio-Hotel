/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.mavenproject2;

/**
 *
 * @author maria
 */
public class Bill {
    public int billNo;
    public String guestName;

    public Bill() {
    }

    public Bill(int billNo, String guestName) {
        this.billNo = billNo;
        this.guestName = guestName;
    }

    public int getBillNo() {
        return billNo;
    }

    public void setBillNo(int billNo) {
        this.billNo = billNo;
    }

    public String getGuestName() {
        return guestName;
    }

    public void setGuestName(String guestName) {
        this.guestName = guestName;
    }

    @Override
    public String toString() {
        return "Devuelve una factura " + billNo + " para el cliente " + guestName;
    }
    
    
}
