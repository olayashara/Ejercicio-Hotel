/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.mavenproject2;

/**
 *
 * @author maria
 */
public class Room {
    public int nroHabitación;
    public int location;
    public int precio;
    public int tiempo;
    public int lavanderia;
    public int daños;
    
    public Room() {
    }

    public Room(int nroHabitación,int location, int precio, int tiempo, int lavanderia, int daños) {
        this.nroHabitación = nroHabitación;
        this.location = location;
        this.precio = precio;
        this.tiempo = tiempo;
        this.lavanderia = lavanderia;
        this.daños = daños;
    }

    public int getLavanderia() {
        return lavanderia;
    }

    public void setLavanderia(int lavanderia) {
        this.lavanderia = lavanderia;
    }

    public int getPrecio() {
        return precio;
    }

    public void setPrecio(int precio) {
        this.precio = precio;
    }

    public int getTiempo() {
        return tiempo;
    }

    public void setTiempo(int tiempo) {
        this.tiempo = tiempo;
    }

    public int getNroHabitación() {
        return nroHabitación;
    }

    public void setNroHabitación(int nroHabitación) {
        this.nroHabitación = nroHabitación;
    }

    public int getLocation() {
        return location;
    }

    public void setLocation(int location) {
        this.location = location;
    }
@Override
    public String toString() {
        return "La habitación nro: " + nroHabitación +" de tipo: "
                + location + " \n con tarifa por día de : " + precio + "dólares \n ocupada en un tiempo de: " + tiempo + "día (s)" + 
                " \n junto con los costos de lavandería: " + lavanderia + " \n y los daños o robos ocasionados: " + daños;
    }
    
}
